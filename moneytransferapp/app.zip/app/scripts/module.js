'use strict';

angular
  .module('app', [
    'ui.router',
    'ngResource',
    'ui.bootstrap',
    'oc.lazyLoad',
    'ngStorage',
    'ngCookies',
    'ngSanitize',
    'ngAnimate',
    'ui.jq',
    'ngTouch',
    'pascalprecht.translate'
    
  ]);
